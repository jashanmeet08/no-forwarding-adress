package com.mystique.ghost.cli;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * @author mystique
 */
@Configuration
@ComponentScan
public class CLIConfig { }
