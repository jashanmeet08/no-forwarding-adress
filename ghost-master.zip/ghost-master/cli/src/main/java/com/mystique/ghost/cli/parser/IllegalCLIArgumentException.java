package com.mystique.ghost.cli.parser;

/**
 * @author mystique
 */
public class IllegalCLIArgumentException extends Exception {

  public IllegalCLIArgumentException(String message) {
    super(message);
  }
}
