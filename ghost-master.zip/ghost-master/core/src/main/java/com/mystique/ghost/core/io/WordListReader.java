package com.mystique.ghost.core.io;

/**
 * @author mystique
 */
public interface WordListReader {

  Iterable<String> read();

}