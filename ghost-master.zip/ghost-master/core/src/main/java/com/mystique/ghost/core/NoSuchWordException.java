package com.mystique.ghost.core;

/**
 * @author mystique
 */
public class NoSuchWordException extends Exception {

  public NoSuchWordException(String message) {
    super(message);
  }
}
