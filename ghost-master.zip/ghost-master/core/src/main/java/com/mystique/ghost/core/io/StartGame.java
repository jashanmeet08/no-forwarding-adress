package com.mystique.ghost.core.io;

import com.mystique.ghost.core.model.WordTree;

/**
 * @author mystique
 */
public class StartGame {

  private WordTree wordTree;

  public void buildTree(){



  }
}
