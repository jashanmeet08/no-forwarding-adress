package com.mystique.ghost.core.model;

/**
 * @author mystique
 */
public class WordTree {

  private final TreeNode root;

  public WordTree(TreeNode root) {
    this.root = root;
  }

  public TreeNode getRootNode() {
    return root;
  }
}
