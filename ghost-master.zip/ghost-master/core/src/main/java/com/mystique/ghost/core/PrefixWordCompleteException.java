package com.mystique.ghost.core;

/**
 * @author mystique
 */
public class PrefixWordCompleteException extends Throwable {

  public PrefixWordCompleteException(String message) {
    super(message);
  }
}
