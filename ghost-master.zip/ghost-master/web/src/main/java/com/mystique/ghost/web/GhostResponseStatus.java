package com.mystique.ghost.web;

/**
 * @author mystique
 */
public enum GhostResponseStatus {
  INVALID, PREFIX_COMPLETE, COMPLETE, SUCCESS
}
